import { registerGateways, registerHandlers, run, type Handler } from "encore.dev/internal/codegen/appinit";

import { getRestaurantMetrics as analytics_getRestaurantMetricsImpl0 } from "../../../../analytics\\api";
import { getMenuItemMetrics as analytics_getMenuItemMetricsImpl1 } from "../../../../analytics\\api";
import { getProcessingTimeMetrics as analytics_getProcessingTimeMetricsImpl2 } from "../../../../analytics\\api";
import { getRestaurantStats as analytics_getRestaurantStatsImpl3 } from "../../../../analytics\\api";
import { generateDailyAnalytics as analytics_generateDailyAnalyticsImpl4 } from "../../../../analytics\\api";
import { cleanupOldData as analytics_cleanupOldDataImpl5 } from "../../../../analytics\\api";
import { getDailyAnalytics as analytics_getDailyAnalyticsImpl6 } from "../../../../analytics\\api";
import { registerOwner as auth_registerOwnerImpl7 } from "../../../../auth\\api";
import { loginOwner as auth_loginOwnerImpl8 } from "../../../../auth\\api";
import { createStaff as auth_createStaffImpl9 } from "../../../../auth\\api";
import { loginStaff as auth_loginStaffImpl10 } from "../../../../auth\\api";
import { generateClientId as auth_generateClientIdImpl11 } from "../../../../auth\\api";
import { updateClientActivity as auth_updateClientActivityImpl12 } from "../../../../auth\\api";
import { getCurrentUser as auth_getCurrentUserImpl13 } from "../../../../auth\\api";
import { createCategory as menu_createCategoryImpl14 } from "../../../../menu\\api";
import { updateCategory as menu_updateCategoryImpl15 } from "../../../../menu\\api";
import { getCategories as menu_getCategoriesImpl16 } from "../../../../menu\\api";
import { createMenuItem as menu_createMenuItemImpl17 } from "../../../../menu\\api";
import { updateMenuItem as menu_updateMenuItemImpl18 } from "../../../../menu\\api";
import { getMenuItems as menu_getMenuItemsImpl19 } from "../../../../menu\\api";
import { createMenuItemOption as menu_createMenuItemOptionImpl20 } from "../../../../menu\\api";
import { updateMenuItemOption as menu_updateMenuItemOptionImpl21 } from "../../../../menu\\api";
import { getMenuItemOptions as menu_getMenuItemOptionsImpl22 } from "../../../../menu\\api";
import { createPromotion as menu_createPromotionImpl23 } from "../../../../menu\\api";
import { getActivePromotions as menu_getActivePromotionsImpl24 } from "../../../../menu\\api";
import { create as order_createImpl25 } from "../../../../order\\api";
import { get as order_getImpl26 } from "../../../../order\\api";
import { updateStatus as order_updateStatusImpl27 } from "../../../../order\\api";
import { getOrderItems as order_getOrderItemsImpl28 } from "../../../../order\\api";
import { getOrderItemOptions as order_getOrderItemOptionsImpl29 } from "../../../../order\\api";
import { subscribeToOrders as order_subscribeToOrdersImpl30 } from "../../../../order\\api";
import { submitReview as order_submitReviewImpl31 } from "../../../../order\\api";
import { getRestaurantReviews as order_getRestaurantReviewsImpl32 } from "../../../../order\\api";
import { getOrderNotifications as order_getOrderNotificationsImpl33 } from "../../../../order\\api";
import { endSession as order_endSessionImpl34 } from "../../../../order\\api";
import { getStatusHistory as order_getStatusHistoryImpl35 } from "../../../../order\\api";
import { create as restaurant_createImpl36 } from "../../../../restaurant\\api";
import { get as restaurant_getImpl37 } from "../../../../restaurant\\api";
import { createTable as restaurant_createTableImpl38 } from "../../../../restaurant\\api";
import { getTables as restaurant_getTablesImpl39 } from "../../../../restaurant\\api";
import { update as restaurant_updateImpl40 } from "../../../../restaurant\\api";
import { updateTable as restaurant_updateTableImpl41 } from "../../../../restaurant\\api";
import { deleteTable as restaurant_deleteTableImpl42 } from "../../../../restaurant\\api";
import * as restaurant_service from "../../../../restaurant\\encore.service";
import * as order_service from "../../../../order\\encore.service";
import * as menu_service from "../../../../menu\\encore.service";
import * as analytics_service from "../../../../analytics\\encore.service";
import * as auth_service from "../../../../auth\\encore.service";

const gateways: any[] = [
];

const handlers: Handler[] = [
    {
        apiRoute: {
            service:           "analytics",
            name:              "getRestaurantMetrics",
            handler:           analytics_getRestaurantMetricsImpl0,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "getMenuItemMetrics",
            handler:           analytics_getMenuItemMetricsImpl1,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "getProcessingTimeMetrics",
            handler:           analytics_getProcessingTimeMetricsImpl2,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "getRestaurantStats",
            handler:           analytics_getRestaurantStatsImpl3,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "generateDailyAnalytics",
            handler:           analytics_generateDailyAnalyticsImpl4,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":false,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "cleanupOldData",
            handler:           analytics_cleanupOldDataImpl5,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":false,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "getDailyAnalytics",
            handler:           analytics_getDailyAnalyticsImpl6,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "auth",
            name:              "registerOwner",
            handler:           auth_registerOwnerImpl7,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: auth_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "auth",
            name:              "loginOwner",
            handler:           auth_loginOwnerImpl8,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: auth_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "auth",
            name:              "createStaff",
            handler:           auth_createStaffImpl9,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: auth_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "auth",
            name:              "loginStaff",
            handler:           auth_loginStaffImpl10,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: auth_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "auth",
            name:              "generateClientId",
            handler:           auth_generateClientIdImpl11,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: auth_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "auth",
            name:              "updateClientActivity",
            handler:           auth_updateClientActivityImpl12,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: auth_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "auth",
            name:              "getCurrentUser",
            handler:           auth_getCurrentUserImpl13,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: auth_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "createCategory",
            handler:           menu_createCategoryImpl14,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "updateCategory",
            handler:           menu_updateCategoryImpl15,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "getCategories",
            handler:           menu_getCategoriesImpl16,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "createMenuItem",
            handler:           menu_createMenuItemImpl17,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "updateMenuItem",
            handler:           menu_updateMenuItemImpl18,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "getMenuItems",
            handler:           menu_getMenuItemsImpl19,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "createMenuItemOption",
            handler:           menu_createMenuItemOptionImpl20,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "updateMenuItemOption",
            handler:           menu_updateMenuItemOptionImpl21,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "getMenuItemOptions",
            handler:           menu_getMenuItemOptionsImpl22,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "createPromotion",
            handler:           menu_createPromotionImpl23,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "getActivePromotions",
            handler:           menu_getActivePromotionsImpl24,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "create",
            handler:           order_createImpl25,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "get",
            handler:           order_getImpl26,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "updateStatus",
            handler:           order_updateStatusImpl27,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getOrderItems",
            handler:           order_getOrderItemsImpl28,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getOrderItemOptions",
            handler:           order_getOrderItemOptionsImpl29,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "subscribeToOrders",
            handler:           order_subscribeToOrdersImpl30,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: true,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":true,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "submitReview",
            handler:           order_submitReviewImpl31,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getRestaurantReviews",
            handler:           order_getRestaurantReviewsImpl32,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getOrderNotifications",
            handler:           order_getOrderNotificationsImpl33,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "endSession",
            handler:           order_endSessionImpl34,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getStatusHistory",
            handler:           order_getStatusHistoryImpl35,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "create",
            handler:           restaurant_createImpl36,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "get",
            handler:           restaurant_getImpl37,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "createTable",
            handler:           restaurant_createTableImpl38,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "getTables",
            handler:           restaurant_getTablesImpl39,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "update",
            handler:           restaurant_updateImpl40,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "updateTable",
            handler:           restaurant_updateTableImpl41,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "deleteTable",
            handler:           restaurant_deleteTableImpl42,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
];

registerGateways(gateways);
registerHandlers(handlers);

await run(import.meta.url);
