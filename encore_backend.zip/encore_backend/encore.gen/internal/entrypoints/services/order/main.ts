import { registerHandlers, run, type Handler } from "encore.dev/internal/codegen/appinit";
import { Worker, isMainThread } from "node:worker_threads";
import { fileURLToPath } from "node:url";
import { availableParallelism } from "node:os";

import { create as createImpl0 } from "../../../../../order\\api";
import { get as getImpl1 } from "../../../../../order\\api";
import { updateStatus as updateStatusImpl2 } from "../../../../../order\\api";
import { getOrderItems as getOrderItemsImpl3 } from "../../../../../order\\api";
import { getOrderItemOptions as getOrderItemOptionsImpl4 } from "../../../../../order\\api";
import { subscribeToOrders as subscribeToOrdersImpl5 } from "../../../../../order\\api";
import { submitReview as submitReviewImpl6 } from "../../../../../order\\api";
import { getRestaurantReviews as getRestaurantReviewsImpl7 } from "../../../../../order\\api";
import { getOrderNotifications as getOrderNotificationsImpl8 } from "../../../../../order\\api";
import { endSession as endSessionImpl9 } from "../../../../../order\\api";
import { getStatusHistory as getStatusHistoryImpl10 } from "../../../../../order\\api";
import * as order_service from "../../../../../order\\encore.service";

const handlers: Handler[] = [
    {
        apiRoute: {
            service:           "order",
            name:              "create",
            handler:           createImpl0,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "get",
            handler:           getImpl1,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "updateStatus",
            handler:           updateStatusImpl2,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getOrderItems",
            handler:           getOrderItemsImpl3,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getOrderItemOptions",
            handler:           getOrderItemOptionsImpl4,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "subscribeToOrders",
            handler:           subscribeToOrdersImpl5,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: true,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":true,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "submitReview",
            handler:           submitReviewImpl6,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getRestaurantReviews",
            handler:           getRestaurantReviewsImpl7,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getOrderNotifications",
            handler:           getOrderNotificationsImpl8,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "endSession",
            handler:           endSessionImpl9,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "order",
            name:              "getStatusHistory",
            handler:           getStatusHistoryImpl10,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: order_service.default.cfg.middlewares || [],
    },
];

registerHandlers(handlers);

await run(import.meta.url);
