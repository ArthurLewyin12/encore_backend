import { registerHandlers, run, type Handler } from "encore.dev/internal/codegen/appinit";
import { Worker, isMainThread } from "node:worker_threads";
import { fileURLToPath } from "node:url";
import { availableParallelism } from "node:os";

import { getRestaurantMetrics as getRestaurantMetricsImpl0 } from "../../../../../analytics\\api";
import { getMenuItemMetrics as getMenuItemMetricsImpl1 } from "../../../../../analytics\\api";
import { getProcessingTimeMetrics as getProcessingTimeMetricsImpl2 } from "../../../../../analytics\\api";
import { getRestaurantStats as getRestaurantStatsImpl3 } from "../../../../../analytics\\api";
import { generateDailyAnalytics as generateDailyAnalyticsImpl4 } from "../../../../../analytics\\api";
import { cleanupOldData as cleanupOldDataImpl5 } from "../../../../../analytics\\api";
import { getDailyAnalytics as getDailyAnalyticsImpl6 } from "../../../../../analytics\\api";
import * as analytics_service from "../../../../../analytics\\encore.service";

const handlers: Handler[] = [
    {
        apiRoute: {
            service:           "analytics",
            name:              "getRestaurantMetrics",
            handler:           getRestaurantMetricsImpl0,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "getMenuItemMetrics",
            handler:           getMenuItemMetricsImpl1,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "getProcessingTimeMetrics",
            handler:           getProcessingTimeMetricsImpl2,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "getRestaurantStats",
            handler:           getRestaurantStatsImpl3,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "generateDailyAnalytics",
            handler:           generateDailyAnalyticsImpl4,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":false,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "cleanupOldData",
            handler:           cleanupOldDataImpl5,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":false,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "analytics",
            name:              "getDailyAnalytics",
            handler:           getDailyAnalyticsImpl6,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: analytics_service.default.cfg.middlewares || [],
    },
];

registerHandlers(handlers);

await run(import.meta.url);
