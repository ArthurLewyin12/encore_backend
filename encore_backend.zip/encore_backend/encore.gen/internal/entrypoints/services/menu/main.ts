import { registerHandlers, run, type Handler } from "encore.dev/internal/codegen/appinit";
import { Worker, isMainThread } from "node:worker_threads";
import { fileURLToPath } from "node:url";
import { availableParallelism } from "node:os";

import { createCategory as createCategoryImpl0 } from "../../../../../menu\\api";
import { updateCategory as updateCategoryImpl1 } from "../../../../../menu\\api";
import { getCategories as getCategoriesImpl2 } from "../../../../../menu\\api";
import { createMenuItem as createMenuItemImpl3 } from "../../../../../menu\\api";
import { updateMenuItem as updateMenuItemImpl4 } from "../../../../../menu\\api";
import { getMenuItems as getMenuItemsImpl5 } from "../../../../../menu\\api";
import { createMenuItemOption as createMenuItemOptionImpl6 } from "../../../../../menu\\api";
import { updateMenuItemOption as updateMenuItemOptionImpl7 } from "../../../../../menu\\api";
import { getMenuItemOptions as getMenuItemOptionsImpl8 } from "../../../../../menu\\api";
import { createPromotion as createPromotionImpl9 } from "../../../../../menu\\api";
import { getActivePromotions as getActivePromotionsImpl10 } from "../../../../../menu\\api";
import * as menu_service from "../../../../../menu\\encore.service";

const handlers: Handler[] = [
    {
        apiRoute: {
            service:           "menu",
            name:              "createCategory",
            handler:           createCategoryImpl0,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "updateCategory",
            handler:           updateCategoryImpl1,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "getCategories",
            handler:           getCategoriesImpl2,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "createMenuItem",
            handler:           createMenuItemImpl3,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "updateMenuItem",
            handler:           updateMenuItemImpl4,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "getMenuItems",
            handler:           getMenuItemsImpl5,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "createMenuItemOption",
            handler:           createMenuItemOptionImpl6,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "updateMenuItemOption",
            handler:           updateMenuItemOptionImpl7,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "getMenuItemOptions",
            handler:           getMenuItemOptionsImpl8,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "createPromotion",
            handler:           createPromotionImpl9,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "menu",
            name:              "getActivePromotions",
            handler:           getActivePromotionsImpl10,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: menu_service.default.cfg.middlewares || [],
    },
];

registerHandlers(handlers);

await run(import.meta.url);
