import { registerHandlers, run, type Handler } from "encore.dev/internal/codegen/appinit";
import { Worker, isMainThread } from "node:worker_threads";
import { fileURLToPath } from "node:url";
import { availableParallelism } from "node:os";

import { create as createImpl0 } from "../../../../../restaurant\\api";
import { get as getImpl1 } from "../../../../../restaurant\\api";
import { createTable as createTableImpl2 } from "../../../../../restaurant\\api";
import { getTables as getTablesImpl3 } from "../../../../../restaurant\\api";
import { update as updateImpl4 } from "../../../../../restaurant\\api";
import { updateTable as updateTableImpl5 } from "../../../../../restaurant\\api";
import { deleteTable as deleteTableImpl6 } from "../../../../../restaurant\\api";
import * as restaurant_service from "../../../../../restaurant\\encore.service";

const handlers: Handler[] = [
    {
        apiRoute: {
            service:           "restaurant",
            name:              "create",
            handler:           createImpl0,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "get",
            handler:           getImpl1,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "createTable",
            handler:           createTableImpl2,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "getTables",
            handler:           getTablesImpl3,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "update",
            handler:           updateImpl4,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "updateTable",
            handler:           updateTableImpl5,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
    {
        apiRoute: {
            service:           "restaurant",
            name:              "deleteTable",
            handler:           deleteTableImpl6,
            raw:               false,
            streamingRequest:  false,
            streamingResponse: false,
        },
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
        middlewares: restaurant_service.default.cfg.middlewares || [],
    },
];

registerHandlers(handlers);

await run(import.meta.url);
