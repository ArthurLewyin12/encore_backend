import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";

const TEST_ENDPOINTS = typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test"
    ? await import("./endpoints_testing.js")
    : null;

export async function createCategory(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.createCategory(params);
    }

    return apiCall("menu", "createCategory", params);
}

export async function updateCategory(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.updateCategory(params);
    }

    return apiCall("menu", "updateCategory", params);
}

export async function getCategories(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getCategories(params);
    }

    return apiCall("menu", "getCategories", params);
}

export async function createMenuItem(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.createMenuItem(params);
    }

    return apiCall("menu", "createMenuItem", params);
}

export async function updateMenuItem(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.updateMenuItem(params);
    }

    return apiCall("menu", "updateMenuItem", params);
}

export async function getMenuItems(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getMenuItems(params);
    }

    return apiCall("menu", "getMenuItems", params);
}

export async function createMenuItemOption(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.createMenuItemOption(params);
    }

    return apiCall("menu", "createMenuItemOption", params);
}

export async function updateMenuItemOption(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.updateMenuItemOption(params);
    }

    return apiCall("menu", "updateMenuItemOption", params);
}

export async function getMenuItemOptions(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getMenuItemOptions(params);
    }

    return apiCall("menu", "getMenuItemOptions", params);
}

export async function createPromotion(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.createPromotion(params);
    }

    return apiCall("menu", "createPromotion", params);
}

export async function getActivePromotions(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getActivePromotions(params);
    }

    return apiCall("menu", "getActivePromotions", params);
}

