import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";
import { registerTestHandler } from "encore.dev/internal/codegen/appinit";

import * as menu_service from "../../../../menu\\encore.service";

export async function createCategory(params) {
    const handler = (await import("../../../../menu\\api")).createCategory;
    registerTestHandler({
        apiRoute: { service: "menu", name: "createCategory", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "createCategory", params);
}

export async function updateCategory(params) {
    const handler = (await import("../../../../menu\\api")).updateCategory;
    registerTestHandler({
        apiRoute: { service: "menu", name: "updateCategory", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "updateCategory", params);
}

export async function getCategories(params) {
    const handler = (await import("../../../../menu\\api")).getCategories;
    registerTestHandler({
        apiRoute: { service: "menu", name: "getCategories", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "getCategories", params);
}

export async function createMenuItem(params) {
    const handler = (await import("../../../../menu\\api")).createMenuItem;
    registerTestHandler({
        apiRoute: { service: "menu", name: "createMenuItem", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "createMenuItem", params);
}

export async function updateMenuItem(params) {
    const handler = (await import("../../../../menu\\api")).updateMenuItem;
    registerTestHandler({
        apiRoute: { service: "menu", name: "updateMenuItem", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "updateMenuItem", params);
}

export async function getMenuItems(params) {
    const handler = (await import("../../../../menu\\api")).getMenuItems;
    registerTestHandler({
        apiRoute: { service: "menu", name: "getMenuItems", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "getMenuItems", params);
}

export async function createMenuItemOption(params) {
    const handler = (await import("../../../../menu\\api")).createMenuItemOption;
    registerTestHandler({
        apiRoute: { service: "menu", name: "createMenuItemOption", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "createMenuItemOption", params);
}

export async function updateMenuItemOption(params) {
    const handler = (await import("../../../../menu\\api")).updateMenuItemOption;
    registerTestHandler({
        apiRoute: { service: "menu", name: "updateMenuItemOption", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "updateMenuItemOption", params);
}

export async function getMenuItemOptions(params) {
    const handler = (await import("../../../../menu\\api")).getMenuItemOptions;
    registerTestHandler({
        apiRoute: { service: "menu", name: "getMenuItemOptions", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "getMenuItemOptions", params);
}

export async function createPromotion(params) {
    const handler = (await import("../../../../menu\\api")).createPromotion;
    registerTestHandler({
        apiRoute: { service: "menu", name: "createPromotion", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "createPromotion", params);
}

export async function getActivePromotions(params) {
    const handler = (await import("../../../../menu\\api")).getActivePromotions;
    registerTestHandler({
        apiRoute: { service: "menu", name: "getActivePromotions", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: menu_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("menu", "getActivePromotions", params);
}

