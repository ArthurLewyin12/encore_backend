import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";

const TEST_ENDPOINTS = typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test"
    ? await import("./endpoints_testing.js")
    : null;

export async function registerOwner(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.registerOwner(params);
    }

    return apiCall("auth", "registerOwner", params);
}

export async function loginOwner(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.loginOwner(params);
    }

    return apiCall("auth", "loginOwner", params);
}

export async function createStaff(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.createStaff(params);
    }

    return apiCall("auth", "createStaff", params);
}

export async function loginStaff(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.loginStaff(params);
    }

    return apiCall("auth", "loginStaff", params);
}

export async function generateClientId(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.generateClientId(params);
    }

    return apiCall("auth", "generateClientId", params);
}

export async function updateClientActivity(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.updateClientActivity(params);
    }

    return apiCall("auth", "updateClientActivity", params);
}

export async function getCurrentUser(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getCurrentUser(params);
    }

    return apiCall("auth", "getCurrentUser", params);
}

