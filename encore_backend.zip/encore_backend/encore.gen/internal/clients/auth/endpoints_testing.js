import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";
import { registerTestHandler } from "encore.dev/internal/codegen/appinit";

import * as auth_service from "../../../../auth\\encore.service";

export async function registerOwner(params) {
    const handler = (await import("../../../../auth\\api")).registerOwner;
    registerTestHandler({
        apiRoute: { service: "auth", name: "registerOwner", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: auth_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("auth", "registerOwner", params);
}

export async function loginOwner(params) {
    const handler = (await import("../../../../auth\\api")).loginOwner;
    registerTestHandler({
        apiRoute: { service: "auth", name: "loginOwner", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: auth_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("auth", "loginOwner", params);
}

export async function createStaff(params) {
    const handler = (await import("../../../../auth\\api")).createStaff;
    registerTestHandler({
        apiRoute: { service: "auth", name: "createStaff", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: auth_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("auth", "createStaff", params);
}

export async function loginStaff(params) {
    const handler = (await import("../../../../auth\\api")).loginStaff;
    registerTestHandler({
        apiRoute: { service: "auth", name: "loginStaff", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: auth_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("auth", "loginStaff", params);
}

export async function generateClientId(params) {
    const handler = (await import("../../../../auth\\api")).generateClientId;
    registerTestHandler({
        apiRoute: { service: "auth", name: "generateClientId", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: auth_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("auth", "generateClientId", params);
}

export async function updateClientActivity(params) {
    const handler = (await import("../../../../auth\\api")).updateClientActivity;
    registerTestHandler({
        apiRoute: { service: "auth", name: "updateClientActivity", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: auth_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("auth", "updateClientActivity", params);
}

export async function getCurrentUser(params) {
    const handler = (await import("../../../../auth\\api")).getCurrentUser;
    registerTestHandler({
        apiRoute: { service: "auth", name: "getCurrentUser", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: auth_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("auth", "getCurrentUser", params);
}

