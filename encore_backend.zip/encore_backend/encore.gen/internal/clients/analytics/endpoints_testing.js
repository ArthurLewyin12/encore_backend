import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";
import { registerTestHandler } from "encore.dev/internal/codegen/appinit";

import * as analytics_service from "../../../../analytics\\encore.service";

export async function getRestaurantMetrics(params) {
    const handler = (await import("../../../../analytics\\api")).getRestaurantMetrics;
    registerTestHandler({
        apiRoute: { service: "analytics", name: "getRestaurantMetrics", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: analytics_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("analytics", "getRestaurantMetrics", params);
}

export async function getMenuItemMetrics(params) {
    const handler = (await import("../../../../analytics\\api")).getMenuItemMetrics;
    registerTestHandler({
        apiRoute: { service: "analytics", name: "getMenuItemMetrics", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: analytics_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("analytics", "getMenuItemMetrics", params);
}

export async function getProcessingTimeMetrics(params) {
    const handler = (await import("../../../../analytics\\api")).getProcessingTimeMetrics;
    registerTestHandler({
        apiRoute: { service: "analytics", name: "getProcessingTimeMetrics", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: analytics_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("analytics", "getProcessingTimeMetrics", params);
}

export async function getRestaurantStats(params) {
    const handler = (await import("../../../../analytics\\api")).getRestaurantStats;
    registerTestHandler({
        apiRoute: { service: "analytics", name: "getRestaurantStats", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: analytics_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("analytics", "getRestaurantStats", params);
}

export async function generateDailyAnalytics(params) {
    const handler = (await import("../../../../analytics\\api")).generateDailyAnalytics;
    registerTestHandler({
        apiRoute: { service: "analytics", name: "generateDailyAnalytics", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: analytics_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":false,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("analytics", "generateDailyAnalytics", params);
}

export async function cleanupOldData(params) {
    const handler = (await import("../../../../analytics\\api")).cleanupOldData;
    registerTestHandler({
        apiRoute: { service: "analytics", name: "cleanupOldData", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: analytics_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":false,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("analytics", "cleanupOldData", params);
}

export async function getDailyAnalytics(params) {
    const handler = (await import("../../../../analytics\\api")).getDailyAnalytics;
    registerTestHandler({
        apiRoute: { service: "analytics", name: "getDailyAnalytics", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: analytics_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("analytics", "getDailyAnalytics", params);
}

