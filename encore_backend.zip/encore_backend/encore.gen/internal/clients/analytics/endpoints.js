import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";

const TEST_ENDPOINTS = typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test"
    ? await import("./endpoints_testing.js")
    : null;

export async function getRestaurantMetrics(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getRestaurantMetrics(params);
    }

    return apiCall("analytics", "getRestaurantMetrics", params);
}

export async function getMenuItemMetrics(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getMenuItemMetrics(params);
    }

    return apiCall("analytics", "getMenuItemMetrics", params);
}

export async function getProcessingTimeMetrics(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getProcessingTimeMetrics(params);
    }

    return apiCall("analytics", "getProcessingTimeMetrics", params);
}

export async function getRestaurantStats(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getRestaurantStats(params);
    }

    return apiCall("analytics", "getRestaurantStats", params);
}

export async function generateDailyAnalytics(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.generateDailyAnalytics(params);
    }

    return apiCall("analytics", "generateDailyAnalytics", params);
}

export async function cleanupOldData(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.cleanupOldData(params);
    }

    return apiCall("analytics", "cleanupOldData", params);
}

export async function getDailyAnalytics(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getDailyAnalytics(params);
    }

    return apiCall("analytics", "getDailyAnalytics", params);
}

