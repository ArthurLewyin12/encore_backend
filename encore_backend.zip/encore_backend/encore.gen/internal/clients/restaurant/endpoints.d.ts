export { create } from "../../../../restaurant\\api.js";
export { get } from "../../../../restaurant\\api.js";
export { createTable } from "../../../../restaurant\\api.js";
export { getTables } from "../../../../restaurant\\api.js";
export { update } from "../../../../restaurant\\api.js";
export { updateTable } from "../../../../restaurant\\api.js";
export { deleteTable } from "../../../../restaurant\\api.js";

