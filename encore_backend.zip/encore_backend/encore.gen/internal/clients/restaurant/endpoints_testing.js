import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";
import { registerTestHandler } from "encore.dev/internal/codegen/appinit";

import * as restaurant_service from "../../../../restaurant\\encore.service";

export async function create(params) {
    const handler = (await import("../../../../restaurant\\api")).create;
    registerTestHandler({
        apiRoute: { service: "restaurant", name: "create", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: restaurant_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("restaurant", "create", params);
}

export async function get(params) {
    const handler = (await import("../../../../restaurant\\api")).get;
    registerTestHandler({
        apiRoute: { service: "restaurant", name: "get", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: restaurant_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("restaurant", "get", params);
}

export async function createTable(params) {
    const handler = (await import("../../../../restaurant\\api")).createTable;
    registerTestHandler({
        apiRoute: { service: "restaurant", name: "createTable", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: restaurant_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("restaurant", "createTable", params);
}

export async function getTables(params) {
    const handler = (await import("../../../../restaurant\\api")).getTables;
    registerTestHandler({
        apiRoute: { service: "restaurant", name: "getTables", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: restaurant_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("restaurant", "getTables", params);
}

export async function update(params) {
    const handler = (await import("../../../../restaurant\\api")).update;
    registerTestHandler({
        apiRoute: { service: "restaurant", name: "update", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: restaurant_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("restaurant", "update", params);
}

export async function updateTable(params) {
    const handler = (await import("../../../../restaurant\\api")).updateTable;
    registerTestHandler({
        apiRoute: { service: "restaurant", name: "updateTable", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: restaurant_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("restaurant", "updateTable", params);
}

export async function deleteTable(params) {
    const handler = (await import("../../../../restaurant\\api")).deleteTable;
    registerTestHandler({
        apiRoute: { service: "restaurant", name: "deleteTable", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: restaurant_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("restaurant", "deleteTable", params);
}

