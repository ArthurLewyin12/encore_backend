import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";
import { registerTestHandler } from "encore.dev/internal/codegen/appinit";

import * as order_service from "../../../../order\\encore.service";

export async function create(params) {
    const handler = (await import("../../../../order\\api")).create;
    registerTestHandler({
        apiRoute: { service: "order", name: "create", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "create", params);
}

export async function get(params) {
    const handler = (await import("../../../../order\\api")).get;
    registerTestHandler({
        apiRoute: { service: "order", name: "get", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "get", params);
}

export async function updateStatus(params) {
    const handler = (await import("../../../../order\\api")).updateStatus;
    registerTestHandler({
        apiRoute: { service: "order", name: "updateStatus", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "updateStatus", params);
}

export async function getOrderItems(params) {
    const handler = (await import("../../../../order\\api")).getOrderItems;
    registerTestHandler({
        apiRoute: { service: "order", name: "getOrderItems", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "getOrderItems", params);
}

export async function getOrderItemOptions(params) {
    const handler = (await import("../../../../order\\api")).getOrderItemOptions;
    registerTestHandler({
        apiRoute: { service: "order", name: "getOrderItemOptions", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "getOrderItemOptions", params);
}

export async function subscribeToOrders(params) {
    const handler = (await import("../../../../order\\api")).subscribeToOrders;
    registerTestHandler({
        apiRoute: { service: "order", name: "subscribeToOrders", raw: false, handler, streamingRequest: false, streamingResponse: true },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":true,"tags":[]},
    });

    return streamOut("order", "subscribeToOrders", params);
}

export async function submitReview(params) {
    const handler = (await import("../../../../order\\api")).submitReview;
    registerTestHandler({
        apiRoute: { service: "order", name: "submitReview", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "submitReview", params);
}

export async function getRestaurantReviews(params) {
    const handler = (await import("../../../../order\\api")).getRestaurantReviews;
    registerTestHandler({
        apiRoute: { service: "order", name: "getRestaurantReviews", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "getRestaurantReviews", params);
}

export async function getOrderNotifications(params) {
    const handler = (await import("../../../../order\\api")).getOrderNotifications;
    registerTestHandler({
        apiRoute: { service: "order", name: "getOrderNotifications", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "getOrderNotifications", params);
}

export async function endSession(params) {
    const handler = (await import("../../../../order\\api")).endSession;
    registerTestHandler({
        apiRoute: { service: "order", name: "endSession", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":true,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "endSession", params);
}

export async function getStatusHistory(params) {
    const handler = (await import("../../../../order\\api")).getStatusHistory;
    registerTestHandler({
        apiRoute: { service: "order", name: "getStatusHistory", raw: false, handler, streamingRequest: false, streamingResponse: false },
        middlewares: order_service.default.cfg.middlewares || [],
        endpointOptions: {"expose":true,"auth":false,"isRaw":false,"isStream":false,"tags":[]},
    });

    return apiCall("order", "getStatusHistory", params);
}

