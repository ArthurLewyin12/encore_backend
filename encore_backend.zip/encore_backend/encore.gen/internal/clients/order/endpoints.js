import { apiCall, streamIn, streamOut, streamInOut } from "encore.dev/internal/codegen/api";

const TEST_ENDPOINTS = typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test"
    ? await import("./endpoints_testing.js")
    : null;

export async function create(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.create(params);
    }

    return apiCall("order", "create", params);
}

export async function get(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.get(params);
    }

    return apiCall("order", "get", params);
}

export async function updateStatus(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.updateStatus(params);
    }

    return apiCall("order", "updateStatus", params);
}

export async function getOrderItems(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getOrderItems(params);
    }

    return apiCall("order", "getOrderItems", params);
}

export async function getOrderItemOptions(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getOrderItemOptions(params);
    }

    return apiCall("order", "getOrderItemOptions", params);
}

export async function subscribeToOrders(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.subscribeToOrders(params);
    }

    return streamOut("order", "subscribeToOrders", params);
}

export async function submitReview(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.submitReview(params);
    }

    return apiCall("order", "submitReview", params);
}

export async function getRestaurantReviews(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getRestaurantReviews(params);
    }

    return apiCall("order", "getRestaurantReviews", params);
}

export async function getOrderNotifications(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getOrderNotifications(params);
    }

    return apiCall("order", "getOrderNotifications", params);
}

export async function endSession(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.endSession(params);
    }

    return apiCall("order", "endSession", params);
}

export async function getStatusHistory(params) {
    if (typeof ENCORE_DROP_TESTS === "undefined" && process.env.NODE_ENV === "test") {
        return TEST_ENDPOINTS.getStatusHistory(params);
    }

    return apiCall("order", "getStatusHistory", params);
}

