import {
  StreamInOutHandlerFn,
  StreamInHandlerFn,
  StreamOutHandlerFn,
  StreamOutWithResponse,
  StreamIn,
  StreamInOut,
} from "encore.dev/api";

import { subscribeToOrders as subscribeToOrders_handler } from "../../../../order\\api.js";

type StreamHandshake<Type extends (...args: any[]) => any> = Parameters<Type> extends [infer H, any] ? H : void;

type StreamRequest<Type> = Type extends
  | StreamInOutHandlerFn<any, infer Req, any>
  | StreamInHandlerFn<any, infer Req, any>
  | StreamOutHandlerFn<any, any>
  ? Req
  : never;

type StreamResponse<Type> = Type extends
  | StreamInOutHandlerFn<any, any, infer Resp>
  | StreamInHandlerFn<any, any, infer Resp>
  | StreamOutHandlerFn<any, infer Resp>
  ? Resp
  : never;

export { create } from "../../../../order\\api.js";
export { get } from "../../../../order\\api.js";
export { updateStatus } from "../../../../order\\api.js";
export { getOrderItems } from "../../../../order\\api.js";
export { getOrderItemOptions } from "../../../../order\\api.js";
export function subscribeToOrders(
  data: StreamHandshake<typeof subscribeToOrders_handler>,
): Promise<
  StreamIn<
    StreamResponse<typeof subscribeToOrders_handler>
  >
>;
export { submitReview } from "../../../../order\\api.js";
export { getRestaurantReviews } from "../../../../order\\api.js";
export { getOrderNotifications } from "../../../../order\\api.js";
export { endSession } from "../../../../order\\api.js";
export { getStatusHistory } from "../../../../order\\api.js";

