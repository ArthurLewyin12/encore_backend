export * as analytics from "../internal/clients/analytics/endpoints";
export * as auth from "../internal/clients/auth/endpoints";
export * as menu from "../internal/clients/menu/endpoints";
export * as order from "../internal/clients/order/endpoints";
export * as restaurant from "../internal/clients/restaurant/endpoints";
