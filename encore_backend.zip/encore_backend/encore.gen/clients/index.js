export * as analytics from "../internal/clients/analytics/endpoints.js";
export * as auth from "../internal/clients/auth/endpoints.js";
export * as menu from "../internal/clients/menu/endpoints.js";
export * as order from "../internal/clients/order/endpoints.js";
export * as restaurant from "../internal/clients/restaurant/endpoints.js";
