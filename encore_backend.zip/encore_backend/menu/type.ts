export interface MenuCategory {
    id: string;
    restaurant_id: string;
    name: string;
    description?: string;
    display_order: number;
    created_at: Date;
    updated_at: Date;
}
  
export interface UpdateCategoryRequest {
    name?: string;
    description?: string;
    display_order?: number;
}

export interface MenuItem {
    id: string;
    restaurant_id: string;
    category_id: string;
    name: string;
    description?: string;
    price: number;
    image_url?: string;
    is_available: boolean;
    preparation_time?: number;
    created_at: Date;
    updated_at: Date;
}
  
export interface UpdateMenuItemRequest {
    category_id?: string;
    name?: string;
    description?: string;
    price?: number;
    image_url?: string;
    is_available?: boolean;
    preparation_time?: number;
}

export interface MenuItemOption {
    id: string;
    menu_item_id: string;
    name: string;
    price_adjustment: number;
    is_available: boolean;
    created_at: Date;
    updated_at: Date;
}
  
export interface UpdateMenuItemOptionRequest {
    name?: string;
    price_adjustment?: number;
    is_available?: boolean;
}

export interface CreateCategoryRequest {
    restaurant_id: string;
    name: string;
    description?: string;
    display_order: number;
}
  
export interface CreateMenuItemRequest {
    restaurant_id: string;
    category_id: string;
    name: string;
    description?: string;
    price: number;
    image_url?: string;
    preparation_time?: number;
}
  
export interface CreateMenuItemOptionRequest {
    menu_item_id: string;
    name: string;
    price_adjustment: number;
}
  
export interface MenuCategoriesResponse {
    categories: MenuCategory[];
}
  
export interface MenuItemsResponse {
    items: MenuItem[];
}
  
export interface MenuItemOptionsResponse {
    options: MenuItemOption[];
}
  
export interface Promotion {
    id: string;
    menu_item_id: string;
    discount_percentage: number;
    start_date: Date;
    end_date: Date;
    is_active: boolean;
}
  