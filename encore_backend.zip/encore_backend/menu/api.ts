import { api } from "encore.dev/api";
import { db } from "./db";
import { APIError } from "encore.dev/api";
import type { 
  MenuCategory,
  MenuCategoriesResponse,
  MenuItem,
  MenuItemsResponse,
  MenuItemOption,
  MenuItemOptionsResponse,
  CreateCategoryRequest,
  UpdateCategoryRequest,
  CreateMenuItemRequest,
  UpdateMenuItemRequest,
  CreateMenuItemOptionRequest,
  UpdateMenuItemOptionRequest,
  Promotion
} from "./type";
import type { AuthenticatedRequest } from "../auth/type";

// Create a new menu category (for owners and staff)
export const createCategory = api(
  { method: "POST", expose: true, path: "/categories", auth: true },
  async (params: AuthenticatedRequest & CreateCategoryRequest): Promise<MenuCategory> => {
    // Verify permissions
    if (params.auth.type === "owner") {
      // Owner can create categories for any restaurant
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${params.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only create categories for their restaurant
      if (params.auth.restaurant_id !== params.restaurant_id) {
        throw APIError.permissionDenied("Staff can only create categories for their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can create categories");
    }

    const result = await db.queryRow<MenuCategory>`
      INSERT INTO menu_categories (restaurant_id, name, description, display_order)
      VALUES (${params.restaurant_id}, ${params.name}, ${params.description}, ${params.display_order})
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to create menu category");
    }
    
    return result;
  }
);

// Update a menu category (for owners and staff)
export const updateCategory = api(
  { method: "PATCH", expose: true, path: "/categories/:id", auth: true },
  async (params: AuthenticatedRequest & { id: string } & UpdateCategoryRequest): Promise<MenuCategory> => {
    // Get category information first
    const category = await db.queryRow<{ restaurant_id: string }>`
      SELECT restaurant_id FROM menu_categories WHERE id = ${params.id}
    `;
    
    if (!category) {
      throw APIError.notFound("Category not found");
    }

    // Verify permissions
    if (params.auth.type === "owner") {
      // Owner can update any category
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${category.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only update categories in their restaurant
      if (params.auth.restaurant_id !== category.restaurant_id) {
        throw APIError.permissionDenied("Staff can only update categories in their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can update categories");
    }

    const result = await db.queryRow<MenuCategory>`
      UPDATE menu_categories 
      SET 
        name = COALESCE(${params.name}, name),
        description = COALESCE(${params.description}, description),
        display_order = COALESCE(${params.display_order}, display_order),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${params.id}
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to update menu category");
    }
    
    return result;
  }
);

// Get all categories for a restaurant (public access)
export const getCategories = api(
  { method: "GET", expose: true, path: "/:restaurant_id/categories" },
  async (params: { restaurant_id: string }): Promise<MenuCategoriesResponse> => {
    const categories = await db.query<MenuCategory>`
      SELECT * FROM menu_categories 
      WHERE restaurant_id = ${params.restaurant_id}
      ORDER BY display_order
    `;
    
    const result: MenuCategory[] = [];
    for await (const category of categories) {
      result.push(category);
    }
    
    return { categories: result };
  }
);

// Create a new menu item (for owners and staff)
export const createMenuItem = api(
  { method: "POST", expose: true, path: "/items", auth: true },
  async (params: AuthenticatedRequest & CreateMenuItemRequest): Promise<MenuItem> => {
    // Verify permissions
    if (params.auth.type === "owner") {
      // Owner can create items for any restaurant
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${params.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only create items for their restaurant
      if (params.auth.restaurant_id !== params.restaurant_id) {
        throw APIError.permissionDenied("Staff can only create items for their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can create menu items");
    }

    // Verify category exists and belongs to the restaurant
    const category = await db.queryRow<{ id: string }>`
      SELECT id FROM menu_categories 
      WHERE id = ${params.category_id} 
      AND restaurant_id = ${params.restaurant_id}
    `;
    
    if (!category) {
      throw APIError.notFound("Category not found or does not belong to this restaurant");
    }

    const result = await db.queryRow<MenuItem>`
      INSERT INTO menu_items (
        restaurant_id, category_id, name, description, 
        price, image_url, preparation_time, is_available
      )
      VALUES (
        ${params.restaurant_id}, ${params.category_id}, ${params.name}, 
        ${params.description}, ${params.price}, ${params.image_url}, 
        ${params.preparation_time}, true
      )
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to create menu item");
    }
    
    return result;
  }
);

// Update a menu item (for owners and staff)
export const updateMenuItem = api(
  { method: "PATCH", expose: true, path: "/items/:id", auth: true },
  async (params: AuthenticatedRequest & { id: string } & UpdateMenuItemRequest): Promise<MenuItem> => {
    // Get item information first
    const item = await db.queryRow<{ restaurant_id: string; category_id: string }>`
      SELECT restaurant_id, category_id FROM menu_items WHERE id = ${params.id}
    `;
    
    if (!item) {
      throw APIError.notFound("Menu item not found");
    }

    // Verify permissions
    if (params.auth.type === "owner") {
      // Owner can update any item
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${item.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only update items in their restaurant
      if (params.auth.restaurant_id !== item.restaurant_id) {
        throw APIError.permissionDenied("Staff can only update items in their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can update menu items");
    }

    // If changing category, verify it exists and belongs to the restaurant
    if (params.category_id) {
      const category = await db.queryRow<{ id: string }>`
        SELECT id FROM menu_categories 
        WHERE id = ${params.category_id} 
        AND restaurant_id = ${item.restaurant_id}
      `;
      
      if (!category) {
        throw APIError.notFound("Category not found or does not belong to this restaurant");
      }
    }

    const result = await db.queryRow<MenuItem>`
      UPDATE menu_items 
      SET 
        category_id = COALESCE(${params.category_id}, category_id),
        name = COALESCE(${params.name}, name),
        description = COALESCE(${params.description}, description),
        price = COALESCE(${params.price}, price),
        image_url = COALESCE(${params.image_url}, image_url),
        is_available = COALESCE(${params.is_available}, is_available),
        preparation_time = COALESCE(${params.preparation_time}, preparation_time),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${params.id}
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to update menu item");
    }
    
    return result;
  }
);

// Get all items for a restaurant (public access)
export const getMenuItems = api(
  { method: "GET", expose: true, path: "/restaurants/:restaurant_id/menu-items" },
  async (params: { restaurant_id: string }): Promise<MenuItemsResponse> => {
    const items = await db.query<MenuItem>`
      SELECT * FROM menu_items 
      WHERE restaurant_id = ${params.restaurant_id}
      AND is_available = true
      ORDER BY category_id, name
    `;
    
    const result: MenuItem[] = [];
    for await (const item of items) {
      result.push(item);
    }
    
    return { items: result };
  }
);

// Create a menu item option (for owners and staff)
export const createMenuItemOption = api(
  { method: "POST", expose: true, path: "/menu-items/:item_id/options", auth: true },
  async (params: AuthenticatedRequest & { item_id: string } & CreateMenuItemOptionRequest): Promise<MenuItemOption> => {
    // Get item information first
    const item = await db.queryRow<{ restaurant_id: string }>`
      SELECT restaurant_id FROM menu_items WHERE id = ${params.item_id}
    `;
    
    if (!item) {
      throw APIError.notFound("Menu item not found");
    }

    // Verify permissions
    if (params.auth.type === "owner") {
      // Owner can create options for any item
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${item.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only create options for items in their restaurant
      if (params.auth.restaurant_id !== item.restaurant_id) {
        throw APIError.permissionDenied("Staff can only create options for items in their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can create menu item options");
    }

    const result = await db.queryRow<MenuItemOption>`
      INSERT INTO menu_item_options (
        menu_item_id, name, price_adjustment, is_available
      )
      VALUES (
        ${params.item_id}, ${params.name}, ${params.price_adjustment}, true
      )
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to create menu item option");
    }
    
    return result;
  }
);

// Update a menu item option (for owners and staff)
export const updateMenuItemOption = api(
  { method: "PATCH", expose: true, path: "/menu-item-options/:id", auth: true },
  async (params: AuthenticatedRequest & { id: string } & UpdateMenuItemOptionRequest): Promise<MenuItemOption> => {
    // Get option information first
    const option = await db.queryRow<{ menu_item_id: string }>`
      SELECT menu_item_id FROM menu_item_options WHERE id = ${params.id}
    `;
    
    if (!option) {
      throw APIError.notFound("Menu item option not found");
    }

    // Get item information
    const item = await db.queryRow<{ restaurant_id: string }>`
      SELECT restaurant_id FROM menu_items WHERE id = ${option.menu_item_id}
    `;
    
    if (!item) {
      throw APIError.notFound("Menu item not found");
    }

    // Verify permissions
    if (params.auth.type === "owner") {
      // Owner can update any option
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${item.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only update options for items in their restaurant
      if (params.auth.restaurant_id !== item.restaurant_id) {
        throw APIError.permissionDenied("Staff can only update options for items in their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can update menu item options");
    }

    const result = await db.queryRow<MenuItemOption>`
      UPDATE menu_item_options 
      SET 
        name = COALESCE(${params.name}, name),
        price_adjustment = COALESCE(${params.price_adjustment}, price_adjustment),
        is_available = COALESCE(${params.is_available}, is_available),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${params.id}
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to update menu item option");
    }
    
    return result;
  }
);

// Get all options for a menu item (public access)
export const getMenuItemOptions = api(
  { method: "GET", expose: true, path: "/menu-items/:item_id/options" },
  async (params: { item_id: string }): Promise<MenuItemOptionsResponse> => {
    const options = await db.query<MenuItemOption>`
      SELECT * FROM menu_item_options 
      WHERE menu_item_id = ${params.item_id}
      AND is_available = true
      ORDER BY name
    `;
    
    const result: MenuItemOption[] = [];
    for await (const option of options) {
      result.push(option);
    }
    
    return { options: result };
  }
);

// Create a promotion for a menu item (only for owners)
export const createPromotion = api(
  { method: "POST", expose: true, path: "/menu-items/:item_id/promotions", auth: true },
  async (params: AuthenticatedRequest & { item_id: string } & Omit<Promotion, "id" | "menu_item_id" | "is_active">): Promise<Promotion> => {
    if (params.auth.type !== "owner") {
      throw APIError.permissionDenied("Only restaurant owners can create promotions");
    }

    // Get item information
    const item = await db.queryRow<{ restaurant_id: string }>`
      SELECT restaurant_id FROM menu_items WHERE id = ${params.item_id}
    `;
    
    if (!item) {
      throw APIError.notFound("Menu item not found");
    }

    // Verify restaurant exists
    const restaurant = await db.queryRow<{ id: string }>`
      SELECT id FROM restaurants WHERE id = ${item.restaurant_id}
    `;
    
    if (!restaurant) {
      throw APIError.notFound("Restaurant not found");
    }

    const promotion = await db.queryRow<Promotion>`
      INSERT INTO promotions (
        menu_item_id,
        discount_percentage,
        start_date,
        end_date,
        is_active
      )
      VALUES (
        ${params.item_id},
        ${params.discount_percentage},
        ${params.start_date},
        ${params.end_date},
        true
      )
      RETURNING *
    `;

    if (!promotion) {
      throw APIError.internal("Failed to create promotion");
    }

    return promotion;
  }
);

// Get active promotions for a restaurant (public access)
export const getActivePromotions = api(
  { method: "GET", expose: true, path: "/restaurants/:restaurant_id/promotions" },
  async (params: { restaurant_id: string }): Promise<{ promotions: Promotion[] }> => {
    const promotions = await db.query<Promotion>`
      SELECT p.*
      FROM promotions p
      JOIN menu_items mi ON mi.id = p.menu_item_id
      WHERE mi.restaurant_id = ${params.restaurant_id}
      AND p.is_active = true
      AND CURRENT_TIMESTAMP BETWEEN p.start_date AND p.end_date
    `;

    const result: Promotion[] = [];
    for await (const promotion of promotions) {
      result.push(promotion);
    }

    return { promotions: result };
  }
); 