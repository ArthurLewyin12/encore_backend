import { Header } from "encore.dev/api";

export interface RestaurantOwner {
    id: string;
    email: string;
    password_hash: string;
    full_name: string;
    created_at: Date;
    updated_at: Date;
}

export interface StaffMember {
    id: string;
    restaurant_id: string;
    full_name: string;
    login_id: string; // Identifiant unique fourni par le propriétaire
    created_at: Date;
    updated_at: Date;
}

export interface AuthParams {
    authorization: Header<"Authorization">;
}

export interface AuthData {
    userID: string;
    type: "owner" | "staff";
    restaurant_id?: string; // Pour le staff
}

export interface AuthenticatedRequest {
    auth: AuthData;
    user_id: string;
}

export interface Client {
    id: string;
    table_id: string;
    restaurant_id: string;
    created_at: Date;
    last_active_at: Date;
}

// Types pour les rôles valides
export type UserRole = "admin" | "restaurant_owner" | "staff";

export interface AuthenticatedUser {
  id: string;
  email: string;
  role: UserRole;
  restaurant_id?: string;
  created_at: Date;
  updated_at: Date;
}