import { api } from "encore.dev/api";
import { SQLDatabase } from "encore.dev/storage/sqldb";
import { APIError } from "encore.dev/api";
import { authHandler } from "encore.dev/auth";
import bcrypt from "bcrypt";
import crypto from "crypto";
import { db } from "./db";
import type { 
    RestaurantOwner, 
    StaffMember, 
    AuthParams, 
    AuthData, 
    Client, 
    AuthenticatedRequest,
    AuthenticatedUser
} from "./type";

// Define the authentication handler
export const auth = authHandler<AuthParams, AuthData>(
  async (params) => {
    const token = params.authorization?.replace("Bearer ", "");
    if (!token) {
      throw APIError.unauthenticated("No token provided");
    }

    // Vérifier d'abord si c'est un propriétaire
    const ownerSession = await db.queryRow<{ owner_id: string }>`
      SELECT o.id as owner_id
      FROM owner_sessions s
      JOIN restaurant_owners o ON o.id = s.owner_id
      WHERE s.token = ${token}
      AND s.expires_at > CURRENT_TIMESTAMP
    `;

    if (ownerSession) {
      return {
        userID: ownerSession.owner_id,
        type: "owner"
      };
    }

    // Sinon vérifier si c'est un membre du staff
    const staffSession = await db.queryRow<{ staff_id: string, restaurant_id: string }>`
      SELECT s.id as staff_id, s.restaurant_id
      FROM staff_sessions ss
      JOIN staff_members s ON s.id = ss.staff_id
      WHERE ss.token = ${token}
      AND ss.expires_at > CURRENT_TIMESTAMP
    `;

    if (staffSession) {
      return {
        userID: staffSession.staff_id,
        type: "staff",
        restaurant_id: staffSession.restaurant_id
      };
    }

    throw APIError.unauthenticated("Invalid or expired token");
  }
);

// Register a new restaurant owner
export const registerOwner = api(
  { method: "POST", expose: true, path: "/owner/register" },
  async (req: { 
    email: string; 
    password: string; 
    full_name: string;
  }): Promise<RestaurantOwner> => {
    // Check if email already exists
    const existingOwner = await db.queryRow<{ id: string }>`
      SELECT id FROM restaurant_owners WHERE email = ${req.email}
    `;

    if (existingOwner) {
      throw APIError.alreadyExists("Email already registered");
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(req.password, salt);

    // Create owner
    const owner = await db.queryRow<RestaurantOwner>`
      INSERT INTO restaurant_owners (email, password_hash, full_name)
      VALUES (${req.email}, ${passwordHash}, ${req.full_name})
      RETURNING id, email, full_name, created_at, updated_at
    `;

    if (!owner) {
      throw APIError.internal("Failed to create restaurant owner");
    }

    return owner;
  }
);

// Login as restaurant owner
export const loginOwner = api(
  { method: "POST", expose: true, path: "/owner/login" },
  async (req: { email: string; password: string }): Promise<{ 
    token: string;
    owner: Omit<RestaurantOwner, 'password_hash'>;
  }> => {
    const owner = await db.queryRow<RestaurantOwner>`
      SELECT * FROM restaurant_owners WHERE email = ${req.email}
    `;

    if (!owner) {
      throw APIError.unauthenticated("Invalid email or password");
    }

    const validPassword = await bcrypt.compare(req.password, owner.password_hash);
    if (!validPassword) {
      throw APIError.unauthenticated("Invalid email or password");
    }

    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days expiration

    await db.exec`
      INSERT INTO owner_sessions (owner_id, token, expires_at)
      VALUES (${owner.id}, ${token}, ${expiresAt})
    `;

    const { password_hash, ...ownerWithoutPassword } = owner;

    return {
      token,
      owner: ownerWithoutPassword,
    };
  }
);

// Create a new staff member (only for restaurant owners)
export const createStaff = api<AuthenticatedRequest & { full_name: string; restaurant_id: string }, StaffMember>(
  { method: "POST", expose: true, path: "/staff", auth: true },
  async (params: AuthenticatedRequest & { full_name: string; restaurant_id: string }): Promise<StaffMember> => {
    // Vérifier que l'utilisateur est bien le propriétaire du restaurant
    if (params.auth.type !== "owner") {
      throw APIError.permissionDenied("Only restaurant owners can create staff members");
    }

    // Générer un identifiant unique pour le staff
    const loginId = crypto.randomBytes(16).toString("hex");

    const staff = await db.queryRow<StaffMember>`
      INSERT INTO staff_members (restaurant_id, full_name, login_id)
      VALUES (${params.restaurant_id}, ${params.full_name}, ${loginId})
      RETURNING *
    `;

    if (!staff) {
      throw APIError.internal("Failed to create staff member");
    }

    return staff;
  }
);

// Login as staff member
export const loginStaff = api(
  { method: "POST", expose: true, path: "/staff/login" },
  async (req: { login_id: string }): Promise<{ 
    token: string;
    staff: StaffMember;
  }> => {
    const staff = await db.queryRow<StaffMember>`
      SELECT * FROM staff_members WHERE login_id = ${req.login_id}
    `;

    if (!staff) {
      throw APIError.unauthenticated("Invalid login ID");
    }

    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 1); // 1 day expiration for staff

    await db.exec`
      INSERT INTO staff_sessions (staff_id, token, expires_at)
      VALUES (${staff.id}, ${token}, ${expiresAt})
    `;

    return {
      token,
      staff,
    };
  }
);

// Generate a new client ID for a table
export const generateClientId = api(
  { method: "POST", expose: true, path: "/client" },
  async (req: { 
    table_id: string;
    restaurant_id: string;
  }): Promise<{ client_id: string }> => {
    const client = await db.queryRow<Client>`
      INSERT INTO clients (table_id, restaurant_id)
      VALUES (${req.table_id}, ${req.restaurant_id})
      RETURNING id
    `;

    if (!client) {
      throw APIError.internal("Failed to create client");
    }

    return { client_id: client.id };
  }
);

// Update client activity
export const updateClientActivity = api(
  { method: "POST", expose: true, path: "/client/:id/activity" },
  async (params: { id: string }): Promise<void> => {
    await db.exec`
      UPDATE clients
      SET last_active_at = CURRENT_TIMESTAMP
      WHERE id = ${params.id}
    `;
  }
);

// Get current user (owner or staff)
export const getCurrentUser = api(
  { method: "GET", expose: true, path: "/me" },
  async (params: AuthenticatedRequest): Promise<AuthenticatedUser> => {
    const user = await db.queryRow<AuthenticatedUser>`
      SELECT id, email, role, restaurant_id, created_at, updated_at
      FROM users
      WHERE id = ${params.user_id}
    `;

    if (!user) {
      throw APIError.notFound("User not found");
    }

    return user;
  }
); 