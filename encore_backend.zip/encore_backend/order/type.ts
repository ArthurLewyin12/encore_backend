import { Topic } from "encore.dev/pubsub";

// Define the order event topic for real-time updates
export interface OrderEvent {
    order_id: string;
    restaurant_id: string;
    table_id: string;
    status: OrderStatus;
    event_type: "created" | "updated" | "status_changed" | "session_ended";
    timestamp: Date;
}

export const orderEvents = new Topic<OrderEvent>("order-events", {
    deliveryGuarantee: "at-least-once",
});

export type OrderStatus = 
    | "pending"      // Order received but not yet confirmed
    | "confirmed"    // Order confirmed by staff
    | "preparing"    // Order being prepared
    | "ready"        // Order ready for delivery
    | "delivered"    // Order delivered to table
    | "session_ended" // Client has finished their session and chosen payment method
    | "completed"    // Order completed (payment handled by restaurant)
    | "cancelled";   // Order cancelled

export interface Order {
    id: string;
    restaurant_id: string;
    table_id: string;
    client_id: string;
    status: OrderStatus;
    total_amount: number;
    notes?: string;
    payment_method?: string;  // Method chosen by client at the end of their session
    session_ended_at?: Date;  // When the client ended their session
    created_at: Date;
    updated_at: Date;
}

export interface OrderItem {
    id: string;
    order_id: string;
    menu_item_id: string;
    quantity: number;
    unit_price: number;
    total_price: number;
    notes?: string;
    created_at: Date;
    updated_at: Date;
}

export interface OrderItemOption {
    id: string;
    order_item_id: string;
    option_id: string;
    quantity: number;
    unit_price_adjustment: number;
    total_price_adjustment: number;
    created_at: Date;
    updated_at: Date;
}

export interface CreateOrderRequest {
    restaurant_id: string;
    table_id: string;
    client_id: string;
    items: Array<{
        menu_item_id: string;
        quantity: number;
        options?: Array<{
            menu_item_option_id: string;
            quantity: number;
        }>;
        notes?: string;
    }>;
    notes?: string;
    payment_method?: string;
}

export interface EndSessionRequest {
    id: string;
    payment_method: string;
}

export interface UpdateOrderStatusRequest {
    status: OrderStatus;
    notes?: string;
}

export interface Review {
    id: string;
    order_id: string;
    restaurant_id: string;
    client_id: string;
    rating: number;
    comment?: string;
    created_at: Date;
}

export interface OrderItemsResponse {
    items: OrderItem[];
}

export interface OrderItemOptionsResponse {
    options: OrderItemOption[];
}

export interface ReviewsResponse {
    reviews: Review[];
}

export interface StreamParams {
    restaurant_id: string;
}

export interface OrderNotification {
    order_id: string;
    status: OrderStatus;
    message: string;
    created_at: Date;
}

export interface OrderStatusHistory {
    id: string;
    order_id: string;
    status: OrderStatus;
    notes?: string;
    created_at: Date;
}

export interface OrderStatusHistoryResponse {
    history: OrderStatusHistory[];
}