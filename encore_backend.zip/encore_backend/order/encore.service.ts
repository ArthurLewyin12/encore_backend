import { Service } from "encore.dev/service";

export default new Service("order"); 