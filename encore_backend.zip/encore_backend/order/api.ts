import { api } from "encore.dev/api";
import { APIError } from "encore.dev/api";
import {  Subscription } from "encore.dev/pubsub";
import  { Order,
  OrderEvent,
  OrderItem,
  OrderItemOption,
  OrderItemOptionsResponse
  ,OrderItemsResponse
  ,OrderNotification
  ,orderEvents
  ,CreateOrderRequest
  ,Review,ReviewsResponse
  ,StreamParams
  , 
  OrderStatus,
  EndSessionRequest,
  OrderStatusHistory,
  OrderStatusHistoryResponse } from "./type";


import { db } from "./db";
import type { AuthenticatedRequest } from "../auth/type";
import type { UpdateOrderStatusRequest } from "./type";


// Create a new order (for clients)
export const create = api(
  { method: "POST", expose: true, path: "/orders" },
  async (params: CreateOrderRequest): Promise<Order> => {
    // Verify table exists and belongs to the restaurant
    const table = await db.queryRow<{ id: string }>`
      SELECT id FROM restaurant_tables 
      WHERE id = ${params.table_id} 
      AND restaurant_id = ${params.restaurant_id}
    `;
    
    if (!table) {
      throw APIError.notFound("Table not found or does not belong to this restaurant");
    }

    // Verify client is assigned to this table
    const client = await db.queryRow<{ id: string }>`
      SELECT id FROM clients 
      WHERE id = ${params.client_id} 
      AND current_table_id = ${params.table_id}
    `;
    
    if (!client) {
      throw APIError.notFound("Client not found or not assigned to this table");
    }

    // Start transaction
    const order = await db.queryRow<Order>`
      WITH new_order AS (
        INSERT INTO orders (
          restaurant_id, table_id, client_id, status, total_amount, notes, payment_method
        )
        VALUES (
          ${params.restaurant_id}, ${params.table_id}, ${params.client_id},
          'pending', 0, ${params.notes}, ${params.payment_method}
        )
        RETURNING *
      )
      SELECT * FROM new_order
    `;

    if (!order) {
      throw APIError.internal("Failed to create order");
    }

    // Calculate total amount and create order items
    let totalAmount = 0;
    for (const item of params.items) {
      // Verify menu item exists and is available
      const menuItem = await db.queryRow<{ price: number; is_available: boolean }>`
        SELECT price, is_available FROM menu_items 
        WHERE id = ${item.menu_item_id} 
        AND restaurant_id = ${params.restaurant_id}
      `;
      
      if (!menuItem) {
        throw APIError.notFound("Menu item not found or does not belong to this restaurant");
      }
      
      if (!menuItem.is_available) {
        throw APIError.failedPrecondition("Menu item is not available");
      }

      // Create order item
      const orderItem = await db.queryRow<OrderItem>`
        INSERT INTO order_items (
          order_id, menu_item_id, quantity, unit_price, total_price, notes
        )
        VALUES (
          ${order.id}, ${item.menu_item_id}, ${item.quantity},
          ${menuItem.price}, ${menuItem.price * item.quantity}, ${item.notes}
        )
        RETURNING *
      `;

      if (!orderItem) {
        throw APIError.internal("Failed to create order item");
      }

      totalAmount += orderItem.total_price;

      // Create order item options if any
      if (item.options) {
        for (const option of item.options) {
          // Verify option exists and is available
          const menuOption = await db.queryRow<{ price_adjustment: number; is_available: boolean }>`
            SELECT price_adjustment, is_available FROM menu_item_options 
            WHERE id = ${option.menu_item_option_id} 
            AND menu_item_id = ${item.menu_item_id}
          `;
          
          if (!menuOption) {
            throw APIError.notFound("Menu item option not found");
          }
          
          if (!menuOption.is_available) {
            throw APIError.failedPrecondition("Menu item option is not available");
          }

          const orderOption = await db.queryRow<OrderItemOption>`
            INSERT INTO order_item_options (
              order_item_id, option_id, quantity,
              unit_price_adjustment, total_price_adjustment
            )
            VALUES (
              ${orderItem.id}, ${option.menu_item_option_id}, ${option.quantity},
              ${menuOption.price_adjustment}, ${menuOption.price_adjustment * option.quantity}
            )
            RETURNING *
          `;

          if (!orderOption) {
            throw APIError.internal("Failed to create order item option");
          }

          totalAmount += orderOption.total_price_adjustment;
        }
      }
    }

    // Update order total amount
    const updatedOrder = await db.queryRow<Order>`
      UPDATE orders 
      SET total_amount = ${totalAmount}
      WHERE id = ${order.id}
      RETURNING *
    `;

    if (!updatedOrder) {
      throw APIError.internal("Failed to update order total amount");
    }

    // Publish order created event
    await orderEvents.publish({
      order_id: updatedOrder.id,
      restaurant_id: updatedOrder.restaurant_id,
      table_id: updatedOrder.table_id,
      status: updatedOrder.status,
      event_type: "created",
      timestamp: new Date()
    });

    return updatedOrder;
  }
);

// Get order details (for clients and staff)
export const get = api(
  { method: "GET", expose: true, path: "/orders/:id" },
  async (params: { id: string }): Promise<Order> => {
    const order = await db.queryRow<Order>`
      SELECT * FROM orders WHERE id = ${params.id}
    `;

    if (!order) {
      throw APIError.notFound("Order not found");
    }

    return order;
  }
);

// Update order status (for staff)
export const updateStatus = api(
  { method: "PATCH", expose: true, path: "/orders/:id/status", auth: true },
  async (params: AuthenticatedRequest & { id: string } & UpdateOrderStatusRequest): Promise<Order> => {
    // Get order information first
    const order = await db.queryRow<{ restaurant_id: string; status: OrderStatus }>`
      SELECT restaurant_id, status FROM orders WHERE id = ${params.id}
    `;
    
    if (!order) {
      throw APIError.notFound("Order not found");
    }

    // Verify permissions
    if (params.auth.type === "owner") {
      // Owner can update any order
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${order.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only update orders in their restaurant
      if (params.auth.restaurant_id !== order.restaurant_id) {
        throw APIError.permissionDenied("Staff can only update orders in their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can update order status");
    }

    // Validate status transition
    const validTransitions: Record<OrderStatus, OrderStatus[]> = {
      pending: ["confirmed", "cancelled"],
      confirmed: ["preparing", "cancelled"],
      preparing: ["ready", "cancelled"],
      ready: ["delivered", "cancelled"],
      delivered: ["session_ended", "cancelled"],
      session_ended: ["completed", "cancelled"],
      completed: [],
      cancelled: []
    };

    if (!validTransitions[order.status].includes(params.status)) {
      throw APIError.failedPrecondition(`Invalid status transition from ${order.status} to ${params.status}`);
    }

    // Start transaction
    const updatedOrder = await db.queryRow<Order>`
      WITH updated_order AS (
        UPDATE orders 
        SET 
          status = ${params.status},
          notes = COALESCE(${params.notes}, notes),
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ${params.id}
        RETURNING *
      ),
      inserted_history AS (
        INSERT INTO order_status_history (order_id, status, notes)
        SELECT id, status, notes FROM updated_order
        RETURNING *
      )
      SELECT * FROM updated_order
    `;

    if (!updatedOrder) {
      throw APIError.internal("Failed to update order status");
    }

    // Publish order status changed event
    await orderEvents.publish({
      order_id: updatedOrder.id,
      restaurant_id: updatedOrder.restaurant_id,
      table_id: updatedOrder.table_id,
      status: updatedOrder.status,
      event_type: "status_changed",
      timestamp: new Date()
    });

    return updatedOrder;
  }
);

// Get order items (for clients and staff)
export const getOrderItems = api(
  { method: "GET", expose: true, path: "/orders/:id/items" },
  async (params: { id: string }): Promise<OrderItemsResponse> => {
    const items = await db.query<OrderItem>`
      SELECT * FROM order_items 
      WHERE order_id = ${params.id}
      ORDER BY created_at
    `;
    
    const result: OrderItem[] = [];
    for await (const item of items) {
      result.push(item);
    }
    
    return { items: result };
  }
);

// Get order item options (for clients and staff)
export const getOrderItemOptions = api(
  { method: "GET", expose: true, path: "/order-items/:id/options" },
  async (params: { id: string }): Promise<OrderItemOptionsResponse> => {
    const options = await db.query<OrderItemOption>`
      SELECT * FROM order_item_options 
      WHERE order_item_id = ${params.id}
      ORDER BY created_at
    `;
    
    const result: OrderItemOption[] = [];
    for await (const option of options) {
      result.push(option);
    }
    
    return { options: result };
  }
);

// Subscribe to order updates (for clients and staff)
export const subscribeToOrders = api.streamOut<OrderNotification>(
  { expose: true, path: "/orders/stream" },
  async (stream) => {
    // Implementation would use WebSocket to stream order updates
    // This is a placeholder for the actual implementation
    throw APIError.unimplemented("Order streaming not yet implemented");
  }
);

// Submit a review (for clients)
export const submitReview = api(
  { method: "POST", expose: true, path: "/orders/:id/review" },
  async (params: { id: string } & Omit<Review, "id" | "order_id" | "restaurant_id" | "created_at">): Promise<Review> => {
    // Get order information
    const order = await db.queryRow<{ restaurant_id: string; client_id: string }>`
      SELECT restaurant_id, client_id FROM orders WHERE id = ${params.id}
    `;
    
    if (!order) {
      throw APIError.notFound("Order not found");
    }

    // Verify client is the one who placed the order
    if (order.client_id !== params.client_id) {
      throw APIError.permissionDenied("Only the client who placed the order can submit a review");
    }

    // Verify order is completed
    const orderStatus = await db.queryRow<{ status: OrderStatus }>`
      SELECT status FROM orders WHERE id = ${params.id}
    `;
    
    if (!orderStatus || orderStatus.status !== "completed") {
      throw APIError.failedPrecondition("Can only review completed orders");
    }

    // Check if review already exists
    const existingReview = await db.queryRow<{ id: string }>`
      SELECT id FROM reviews WHERE order_id = ${params.id}
    `;
    
    if (existingReview) {
      throw APIError.alreadyExists("Review already exists for this order");
    }

    const review = await db.queryRow<Review>`
      INSERT INTO reviews (
        order_id, restaurant_id, client_id, rating, comment
      )
      VALUES (
        ${params.id}, ${order.restaurant_id}, ${params.client_id},
        ${params.rating}, ${params.comment}
      )
      RETURNING *
    `;

    if (!review) {
      throw APIError.internal("Failed to create review");
    }

    return review;
  }
);

// Get reviews for a restaurant
export const getRestaurantReviews = api(
  { method: "GET", expose: true, path: "/restaurant/:restaurant_id/reviews" },
  async (params: { restaurant_id: string }): Promise<ReviewsResponse> => {
    const reviews = await db.query<Review>`
      SELECT * FROM reviews
      WHERE restaurant_id = ${params.restaurant_id}
      ORDER BY created_at DESC
    `;

    const result: Review[] = [];
    for await (const review of reviews) {
      result.push(review);
    }

    return { reviews: result };
  }
);

// Get order notifications
export const getOrderNotifications = api(
  { method: "GET", expose: true, path: "/orders/:id/notifications" },
  async (params: { id: string }): Promise<{ notifications: OrderNotification[] }> => {
    const notifications = await db.query<OrderNotification>`
      SELECT 
        order_id,
        status,
        CASE 
          WHEN status = 'pending' THEN 'Votre commande a été reçue'
          WHEN status = 'preparing' THEN 'Votre commande est en préparation'
          WHEN status = 'ready' THEN 'Votre commande est prête'
          WHEN status = 'delivered' THEN 'Votre commande a été livrée'
          WHEN status = 'cancelled' THEN 'Votre commande a été annulée'
          ELSE 'Statut de commande mis à jour'
        END as message,
        created_at
      FROM order_status_history
      WHERE order_id = ${params.id}
      ORDER BY created_at DESC
    `;

    const result: OrderNotification[] = [];
    for await (const notification of notifications) {
      result.push(notification);
    }

    return { notifications: result };
  }
);

// End session and choose payment method (for clients)
export const endSession = api(
    { method: "POST", expose: true, path: "/orders/:id/end-session", auth: true },
    async (params: AuthenticatedRequest & EndSessionRequest): Promise<Order> => {
        // Get order information
        const order = await db.queryRow<{ client_id: string; status: OrderStatus }>`
            SELECT client_id, status FROM orders WHERE id = ${params.id}
        `;
        
        if (!order) {
            throw APIError.notFound("Order not found");
        }

        // Verify client is the one who placed the order
        if (order.client_id !== params.auth.userID) {
            throw APIError.permissionDenied("Only the client who placed the order can end the session");
        }

        // Verify order is in a valid state to end session
        if (order.status !== "delivered") {
            throw APIError.failedPrecondition("Can only end session for delivered orders");
        }

        const updatedOrder = await db.queryRow<Order>`
            UPDATE orders 
            SET 
                status = 'session_ended',
                payment_method = ${params.payment_method},
                session_ended_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ${params.id}
            RETURNING *
        `;

        if (!updatedOrder) {
            throw APIError.internal("Failed to update order status");
        }

        // Publish session ended event
        await orderEvents.publish({
            order_id: updatedOrder.id,
            restaurant_id: updatedOrder.restaurant_id,
            table_id: updatedOrder.table_id,
            status: updatedOrder.status,
            event_type: "session_ended",
            timestamp: new Date()
        });

        return updatedOrder;
    }
);

// Get order status history
export const getStatusHistory = api(
  { method: "GET", expose: true, path: "/orders/:id/history" },
  async (params: { id: string }): Promise<OrderStatusHistoryResponse> => {
    // Verify order exists
    const order = await db.queryRow<{ id: string }>`
      SELECT id FROM orders WHERE id = ${params.id}
    `;
    
    if (!order) {
      throw APIError.notFound("Order not found");
    }

    const history = await db.query<OrderStatusHistory>`
      SELECT * FROM order_status_history
      WHERE order_id = ${params.id}
      ORDER BY created_at DESC
    `;

    const result: OrderStatusHistory[] = [];
    for await (const entry of history) {
      result.push(entry);
    }

    return { history: result };
  }
);