import { api } from "encore.dev/api";
import { db } from "./db";
import { APIError } from "encore.dev/api";
import type { 
  Restaurant,
  CreateRestaurantRequest,
  UpdateRestaurantRequest,
  CreateTableRequest,
  UpdateTableRequest,
  Table,
  TablesResponse 
} from "./type";
import type { AuthenticatedRequest } from "../auth/type";



// Create a new restaurant (only for owners)
export const create = api(
  { method: "POST", expose: true, auth: true },
  async (params: AuthenticatedRequest & CreateRestaurantRequest): Promise<Restaurant> => {
    if (params.auth.type !== "owner") {
      throw APIError.permissionDenied("Only restaurant owners can create restaurants");
    }

    const result = await db.queryRow<Restaurant>`
      INSERT INTO restaurants (name, description, address, phone, email, logo_url)
      VALUES (${params.name}, ${params.description}, ${params.address}, ${params.phone}, ${params.email}, ${params.logo_url})
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to create restaurant");
    }
    
    return result;
  }
);

// Get restaurant by ID (public access)
export const get = api(
  { method: "GET", expose: true, path: "/restaurants/:id" },
  async (params: { id: string }): Promise<Restaurant> => {
    const restaurant = await db.queryRow<Restaurant>`
      SELECT * FROM restaurants WHERE id = ${params.id}
    `;
    
    if (!restaurant) {
      throw APIError.notFound("Restaurant not found");
    }
    
    return restaurant;
  }
);

// Create a new table (only for owners and staff of the restaurant)
export const createTable = api(
  { method: "POST", expose: true, path: "/tables", auth: true },
  async (params: AuthenticatedRequest & CreateTableRequest): Promise<Table> => {
    // Verify restaurant ownership or staff membership
    if (params.auth.type === "owner") {
      // Owner can create tables for any restaurant
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${params.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only create tables for their restaurant
      if (params.auth.restaurant_id !== params.restaurant_id) {
        throw APIError.permissionDenied("Staff can only create tables for their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can create tables");
    }

    const result = await db.queryRow<Table>`
      INSERT INTO restaurant_tables (restaurant_id, table_number, capacity)
      VALUES (${params.restaurant_id}, ${params.table_number}, ${params.capacity})
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to create table");
    }
    
    return result;
  }
);

// Get all tables for a restaurant (public access)
export const getTables = api(
  { method: "GET", expose: true, path: "/restaurants/:id/tables" },
  async (params: { id: string }): Promise<TablesResponse> => {
    const tables = await db.query<Table>`
      SELECT * FROM restaurant_tables 
      WHERE restaurant_id = ${params.id}
      ORDER BY table_number
    `;
    
    const result: Table[] = [];
    for await (const table of tables) {
      result.push(table);
    }
    
    return { tables: result };
  }
);

// Update restaurant information (only for owners)
export const update = api(
  { method: "PATCH", expose: true, path: "/restaurants/:id", auth: true },
  async (params: AuthenticatedRequest & { id: string } & UpdateRestaurantRequest): Promise<Restaurant> => {
    if (params.auth.type !== "owner") {
      throw APIError.permissionDenied("Only restaurant owners can update restaurant information");
    }

    // Verify restaurant exists and belongs to the owner
    const restaurant = await db.queryRow<{ id: string }>`
      SELECT id FROM restaurants WHERE id = ${params.id}
    `;
    
    if (!restaurant) {
      throw APIError.notFound("Restaurant not found");
    }

    const result = await db.queryRow<Restaurant>`
      UPDATE restaurants 
      SET 
        name = COALESCE(${params.name}, name),
        description = COALESCE(${params.description}, description),
        address = COALESCE(${params.address}, address),
        phone = COALESCE(${params.phone}, phone),
        email = COALESCE(${params.email}, email),
        logo_url = COALESCE(${params.logo_url}, logo_url),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${params.id}
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to update restaurant");
    }
    
    return result;
  }
);

// Update table information (for owners and staff)
export const updateTable = api(
  { method: "PATCH", expose: true, path: "/tables/:id", auth: true },
  async (params: AuthenticatedRequest & { id: string } & UpdateTableRequest): Promise<Table> => {
    // Get table information first
    const table = await db.queryRow<{ restaurant_id: string }>`
      SELECT restaurant_id FROM restaurant_tables WHERE id = ${params.id}
    `;
    
    if (!table) {
      throw APIError.notFound("Table not found");
    }

    // Verify permissions
    if (params.auth.type === "owner") {
      // Owner can update any table
      const restaurant = await db.queryRow<{ id: string }>`
        SELECT id FROM restaurants WHERE id = ${table.restaurant_id}
      `;
      if (!restaurant) {
        throw APIError.notFound("Restaurant not found");
      }
    } else if (params.auth.type === "staff") {
      // Staff can only update tables in their restaurant
      if (params.auth.restaurant_id !== table.restaurant_id) {
        throw APIError.permissionDenied("Staff can only update tables in their own restaurant");
      }
    } else {
      throw APIError.permissionDenied("Only restaurant owners and staff can update tables");
    }

    const result = await db.queryRow<Table>`
      UPDATE restaurant_tables 
      SET 
        table_number = COALESCE(${params.table_number}, table_number),
        capacity = COALESCE(${params.capacity}, capacity),
        is_available = COALESCE(${params.is_available}, is_available),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ${params.id}
      RETURNING *
    `;
    
    if (!result) {
      throw APIError.internal("Failed to update table");
    }
    
    return result;
  }
);

// Delete a table (only for owners)
export const deleteTable = api(
  { method: "DELETE", expose: true, path: "/tables/:id", auth: true },
  async (params: AuthenticatedRequest & { id: string }): Promise<void> => {
    if (params.auth.type !== "owner") {
      throw APIError.permissionDenied("Only restaurant owners can delete tables");
    }

    // Get table information first
    const table = await db.queryRow<{ restaurant_id: string }>`
      SELECT restaurant_id FROM restaurant_tables WHERE id = ${params.id}
    `;
    
    if (!table) {
      throw APIError.notFound("Table not found");
    }

    // Verify restaurant exists
    const restaurant = await db.queryRow<{ id: string }>`
      SELECT id FROM restaurants WHERE id = ${table.restaurant_id}
    `;
    
    if (!restaurant) {
      throw APIError.notFound("Restaurant not found");
    }

    // Check if table has any active orders
    const activeOrders = await db.queryRow<{ count: number }>`
      SELECT COUNT(*) as count FROM orders 
      WHERE table_id = ${params.id} 
      AND status NOT IN ('completed', 'cancelled')
    `;

    if (activeOrders && activeOrders.count > 0) {
      throw APIError.failedPrecondition("Cannot delete table with active orders");
    }

    await db.exec`
      DELETE FROM restaurant_tables WHERE id = ${params.id}
    `;
  }
); 