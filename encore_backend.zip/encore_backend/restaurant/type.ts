export interface Restaurant {
    id: string;
    name: string;
    description?: string;
    address: string;
    phone: string;
    email: string;
    logo_url?: string;
    qr_code_url?: string;
    created_at: Date;
    updated_at: Date;
  }
  
export   interface CreateRestaurantRequest {
    name: string;
    description?: string;
    address: string;
    phone: string;
    email: string;
    logo_url?: string;
  }
  
export interface UpdateRestaurantRequest {
    name?: string;
    description?: string;
    address?: string;
    phone?: string;
    email?: string;
    logo_url?: string;
}
  
export interface Table {
    id: string;
    restaurant_id: string;
    table_number: string;
    capacity: number;
    is_available: boolean;
    created_at: Date;
    updated_at: Date;
  }
  
export interface CreateTableRequest {
    restaurant_id: string;
    table_number: string;
    capacity: number;
  }
  
export interface UpdateTableRequest {
    table_number?: string;
    capacity?: number;
    is_available?: boolean;
}
  
export  interface TablesResponse {
    tables: Table[];
  }